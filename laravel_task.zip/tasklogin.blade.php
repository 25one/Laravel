<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Login for the Task</title>
<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<link rel="stylesheet" type="text/css" href="{{ asset('css/mine_task.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/app.css') }}">
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/mine_task.js') }}"></script>
  </head>

  <body>

<div class="container">

<div class="people_login">

    {{ Form::open(['url' => '../public/tasklogin', 'method' => 'post', 'name' => 'form_people']) }}

      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Login
      </div>
      <div class="cell_td">
      <input type="text" name="login" value="<?php if(Input::old('login')){echo Input::old('login');} else if(isset($message_array['old_login'])){echo $message_array['old_login'];} else {echo 'alex';} ?>" />
      {{ Form::label('login', '(a-zA-Z0-9)', array('class' => 'title_login')) }}
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Password
      </div>
      <div class="cell_td">
      <input type="password" name="password" value="12345678" maxlength="100" />
      {{ Form::label('password', '(required)', array('class' => 'title_login')) }}
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td">
      <input type="button" name="button_login" value="Login" />
      </div>
      <div class="cell_td">
      <?php
      if(isset($message_array['error_login'])) { ?>
         <span class="span_error"><?php echo $message_array['error_login']; ?></span>
      <?php } else { ?>
         <span class="span_error"><span style="color:green;">alex-12345678, serg-87654321</span></span>
      <?php } ?>
      </div>
      </div>

    {{ Form::close() }}

</div>

</div>

  </body>
</html>