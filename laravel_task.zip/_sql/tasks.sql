-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: ag248566.mysql.ukraine.com.ua
-- Время создания: Фев 15 2018 г., 09:54
-- Версия сервера: 5.7.16-10-log
-- Версия PHP: 7.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ag248566_laravel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE `tasks` (
  `id` int(12) NOT NULL,
  `id_user` int(12) NOT NULL,
  `name_task` varchar(250) NOT NULL,
  `content_task` text NOT NULL,
  `status` int(1) NOT NULL,
  `datetime_start` datetime DEFAULT NULL,
  `datetime_end` datetime DEFAULT NULL,
  `pause_count` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`id`, `id_user`, `name_task`, `content_task`, `status`, `datetime_start`, `datetime_end`, `pause_count`) VALUES
(52, 1, 'task 1 - name', 'task 1 - content', 0, NULL, NULL, 0),
(55, 2, 'tasl 11 - name', 'tasl 11 - content', 0, NULL, NULL, 0),
(56, 2, 'tasl 22 - name', 'tasl 22 - content', 0, NULL, NULL, 0),
(67, 1, 'task 2 - name', 'task 2 - content', 2, '2018-02-15 07:53:19', '2018-02-15 07:53:24', 7),
(72, 1, 'task 3 - name', 'task 3 - content', 0, NULL, NULL, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
