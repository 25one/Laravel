<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Taskcreate;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Session;
use DateTime;

class TaskcreateController extends Controller
{

    public function __construct(Taskcreate $taskcreate)
    {
        $this->taskcreate = $taskcreate;
    }

    public function index(Request $request)
    {
        if(Input::get('button_add_task')) {
           $id_user=Crypt::decryptString($request->dd);
           Session::put('id_user', $id_user);
           $method='insert';
           $query_string='insert into `tasks`(`id_user`, `name_task`, `content_task`, `status`, `datetime_start`, `datetime_end`, `pause_count`) values('.Session::get('id_user').', "'.$request->input('name_task').'", "'.$request->input('content_task').'", 0, NULL, NULL, 0)';
           $results=$this->taskcreate->make($request, $method, $query_string);
           $method='select';
           $query_string='select `tasks`.`id`, `tasks`.`id_user`, `tasks`.`name_task`, `tasks`.`content_task`, `tasks`.`status`, `tasks`.`datetime_start`, `tasks`.`datetime_end`, (UNIX_TIMESTAMP("'.date('Y-m-d H:i:s').'")-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result_1, (UNIX_TIMESTAMP(`tasks`.`datetime_end`)-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result_2, `tasks`.`pause_count` from `tasks` where `tasks`.`id_user`='.Session::get('id_user');
           $results=$this->taskcreate->make($request, $method, $query_string);
           return view('taskcreate/taskcreate', ['results'=>$results]);
        }
        else if(Input::get('button_delete_task')) {
           $id_user=Crypt::decryptString($request->dd);
           Session::put('id_user', $id_user);
           $method='delete';
           $query_string='delete from `tasks` where `tasks`.`id`='.$request->button_delete_task;
           $results=$this->taskcreate->make($request, $method, $query_string);
           $method='select';
           $query_string='select `tasks`.`id`, `tasks`.`id_user`, `tasks`.`name_task`, `tasks`.`content_task`, `tasks`.`status`, `tasks`.`datetime_start`, `tasks`.`datetime_end`, (UNIX_TIMESTAMP("'.date('Y-m-d H:i:s').'")-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result_1, (UNIX_TIMESTAMP(`tasks`.`datetime_end`)-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result_2, `tasks`.`pause_count` from `tasks` where `tasks`.`id_user`='.Session::get('id_user');
           $results=$this->taskcreate->make($request, $method, $query_string);
           return view('taskcreate/taskcreate', ['results'=>$results]);
        }
        else if(Input::get('button_update_task')) {
           Session::put('id_task', $request->button_update_task);
           $id_user=Crypt::decryptString($request->dd);
           Session::put('id_user', $id_user);
           return redirect('/taskupdate');
        }
        else {
           $method='select';
           $query_string='select `tasks`.`id`, `tasks`.`id_user`, `tasks`.`name_task`, `tasks`.`content_task`, `tasks`.`status`, `tasks`.`datetime_start`, `tasks`.`datetime_end`, (UNIX_TIMESTAMP("'.date('Y-m-d H:i:s').'")-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result_1, (UNIX_TIMESTAMP(`tasks`.`datetime_end`)-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result_2, `tasks`.`pause_count` from `tasks` where `tasks`.`id_user`='.Session::get('id_user');
           $results=$this->taskcreate->make($request, $method, $query_string);
           return view('taskcreate/taskcreate', ['results'=>$results]);
        }

    }

    public function taskstart($id_task)
    {
       $method='update';
       $query_string='update `tasks` set `tasks`.`status`=1, `tasks`.`datetime_start`="'.date('Y-m-d H:i:s').'", `tasks`.`pause_count`=if(`tasks`.`datetime_end` is not null, 0, `tasks`.`pause_count`), `tasks`.`datetime_end`=NULL where `tasks`.`id`='.$id_task;
       $results=$this->taskcreate->make('', $method, $query_string);
    }

    public function taskstop($id_task)
    {
      $method='select';
      $query_string='select `tasks`.`id`, `tasks`.`id_user`, `tasks`.`name_task`, `tasks`.`content_task`, `tasks`.`status`, `tasks`.`datetime_start`, `tasks`.`datetime_end`, (UNIX_TIMESTAMP("'.date('Y-m-d H:i:s').'")-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result, `tasks`.`pause_count` from `tasks` where `tasks`.`id`='.$id_task;
      $results=$this->taskcreate->make('', $method, $query_string);
      if($results[0]->status==1 or $results[0]->status==3) {
       $method='update';
       $query_string='update `tasks` set `tasks`.`status`=2, `tasks`.`datetime_end`="'.date('Y-m-d H:i:s').'" where `tasks`.`id`='.$id_task;
       $resultss=$this->taskcreate->make('', $method, $query_string);
       if($results[0]->pause_count>0 and $results[0]->status==1) {
          $secondintodate=$this->taskcreate->second_into_date($results[0]->datetime_result+$results[0]->pause_count);
       }
       else if($results[0]->pause_count>0 and $results[0]->status==3) {
          $secondintodate=$this->taskcreate->second_into_date($results[0]->pause_count);
       }
       else if($results[0]->pause_count==0) {
          $secondintodate=$this->taskcreate->second_into_date($results[0]->datetime_result);
       }
       $arr_data['time_result']="<span style='color:red;'>".$secondintodate['days']."</span> days <span style='color:red;'>". $secondintodate['hours'] . "</span> hours <span style='color:red;'>" . $secondintodate['minutes']."</span> minutes <span style='color:red;'>".$secondintodate['seconds']."</span> seconds";
      }
      else {
       $arr_data['error']="The task wasn't started or it was already stoped!";
      }
      $arr_data_json=json_encode($arr_data);
      echo $arr_data_json;
    }

    public function taskpause($id_task)
    {
      $method='select';
      $query_string='select `tasks`.`id`, `tasks`.`id_user`, `tasks`.`name_task`, `tasks`.`content_task`, `tasks`.`status`, `tasks`.`datetime_start`, `tasks`.`datetime_end`, (UNIX_TIMESTAMP("'.date('Y-m-d H:i:s').'")-UNIX_TIMESTAMP(`tasks`.`datetime_start`)) as datetime_result, `tasks`.`pause_count` from `tasks` where `tasks`.`id`='.$id_task;
      $results=$this->taskcreate->make('', $method, $query_string);
      if($results[0]->status==1) {
       $method='update';
       $query_string='update `tasks` set `tasks`.`status`=3, `tasks`.`datetime_start`=NULL, `tasks`.`pause_count`=(`tasks`.`pause_count`+'.$results[0]->datetime_result.') where `tasks`.`id`='.$id_task;
       $resultss=$this->taskcreate->make('', $method, $query_string);
       $secondintodate=$this->taskcreate->second_into_date($results[0]->pause_count+$results[0]->datetime_result);
       $arr_data['time_result']="<span style='color:blue;'>".$secondintodate['days']."</span> days <span style='color:blue;'>". $secondintodate['hours'] . "</span> hours <span style='color:blue;'>" . $secondintodate['minutes']."</span> minutes <span style='color:blue;'>".$secondintodate['seconds']."</span> seconds";
      }
      else {
       $arr_data['error']="The task wasn't started or it was already stoped or it's already on the pause!";
      }
      $arr_data_json=json_encode($arr_data);
      echo $arr_data_json;
    }

}
