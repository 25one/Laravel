@if (session('id_task'))
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Update of Task</title>
<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<link rel="stylesheet" type="text/css" href="{{ asset('css/mine_task.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/app.css') }}">
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/mine_task.js') }}"></script>
  </head>

  <body>

<div class="container">

{{ Form::open(['url' => '../public/taskupdate', 'method' => 'post', 'name' => 'task_update']) }}

<div class="update_task">

    <div class="table_update_task">
      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Name of task
      </div>
      <div class="cell_td">
      <input type="text" name="name_task" class="name_task" value="<?php echo($results[0]->name_task); ?>" />
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Content of task
      </div>
      <div class="cell_td">
      <textarea name="content_task" class="content_task"><?php echo($results[0]->content_task); ?></textarea>
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td">
      <input type="button" name="button_update_task" value="Save" />
      </div>
      <div class="cell_td">
      &nbsp;
      </div>
      </div>
    </div>

</div>

{{ Form::close() }}

</div>

  </body>
</html>
@endif