@if (session('id_user'))
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Create of Task (add, delete, go to update)</title>
<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<link rel="stylesheet" type="text/css" href="{{ asset('css/mine_task.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/app.css') }}">
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/mine_task.js') }}"></script>
  </head>

  <body>

<div class="container">

<script>
BaseRecord.var_dump = '{{ Crypt::encryptString(session('id_user')) }}';
</script>

{{ Form::open(['url' => '../public/taskcreate', 'method' => 'post', 'name' => 'task_create']) }}

<div class="new_task">
    <input type="hidden" name="dd" value="{{ Crypt::encryptString(session('id_user')) }}" />
    <div class="table_new_task">
      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Name of new task
      </div>
      <div class="cell_td">
      <input type="text" name="name_task" class="name_task" value="" placeholder="write name of new task" />
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Content of new task
      </div>
      <div class="cell_td">
      <textarea name="content_task" class="content_task" placeholder="write content of new task"></textarea>
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td">
      <input type="button" name="button_add_task" value="Add" />
      </div>
      <div class="cell_td">
      &nbsp;
      </div>
      </div>
    </div>

</div>

<hr>

<div class="all_task">
<div class="table_all_task_title">
<div class="row_td">
      <div class="cell_td cell_th" style="width:40%;">
      Name of task
      </div>
      <div class="cell_td cell_th" style="width:20%;">
      Status of task
      </div>
      <div class="cell_td cell_th" style="width:20%;">
      Time of task
      </div>
      <div class="cell_td cell_th" style="width:10%;">
      Update
      </div>
      <div class="cell_td cell_th" style="width:10%;">
      Delete
      </div>
</div>
</div>
<div class="table_all_task_content">
<?php
if(isset($results)) {
foreach($results as $k1=>$results1) {
?>
<div class="row_td">
      <div class="cell_td" style="width:40%;">
      <?php echo($results1->name_task); ?>
      </div>
      <div class="cell_td cell_td_center" style="width:20%;">
      <img src="{{asset('images/button_start.png')}}" class="button_status_start" name="<?php echo($results1->id); ?>" style="opacity:<?php if($results1->status==1) {echo '1.0;';} else {echo '0.5;';} ?>" alt="" />
      <img src="{{asset('images/button_stop.png')}}" class="button_status_stop" name="<?php echo($results1->id); ?>" style="opacity:<?php if($results1->status==2) {echo '1.0;';} else {echo '0.5;';} ?>;" alt="" />
      <img src="{{asset('images/button_pause.png')}}" class="button_status_pause" name="<?php echo($results1->id); ?>" style="opacity:<?php if($results1->status==3) {echo '1.0;';} else {echo '0.5;';} ?>;" alt="" />
      </div>
      <div class="cell_td cell_td_center datetime_result" id="id_task<?php echo($results1->id); ?>" style="width:20%;">
      <?php
      if($results1->status==1) {
       $secondintodate=App\Taskcreate::second_into_date($results1->datetime_result_1+$results1->pause_count);
       echo "<span style='color:green;'>".$secondintodate['days']."</span> days <span style='color:green;'>". $secondintodate['hours'] . "</span> hours <span style='color:green;'>" . $secondintodate['minutes']."</span> minutes <span style='color:green;'>".$secondintodate['seconds']."</span> seconds";
      }
      else if($results1->status==2) {
       if($results1->pause_count>0) {
        if(!$results1->datetime_start) {
          $secondintodate=App\Taskcreate::second_into_date($results1->pause_count);
        }
        else {
          $secondintodate=App\Taskcreate::second_into_date($results1->datetime_result_2+$results1->pause_count);
        }
       }
       else if($results1->pause_count==0) {
          $secondintodate=App\Taskcreate::second_into_date($results1->datetime_result_2);
       }
       echo "<span style='color:red;'>".$secondintodate['days']."</span> days <span style='color:red;'>". $secondintodate['hours'] . "</span> hours <span style='color:red;'>" . $secondintodate['minutes']."</span> minutes <span style='color:red;'>".$secondintodate['seconds']."</span> seconds";

     }
      else if($results1->status==3) {
       $secondintodate=App\Taskcreate::second_into_date($results1->pause_count);
       echo "<span style='color:blue;'>".$secondintodate['days']."</span> days <span style='color:blue;'>". $secondintodate['hours'] . "</span> hours <span style='color:blue;'>" . $secondintodate['minutes']."</span> minutes <span style='color:blue;'>".$secondintodate['seconds']."</span> seconds";
      }
      ?>
      </div>
      <div class="cell_td cell_td_center" style="width:10%;">
      <button type="button" name="button_update_task" value="<?php echo($results1->id); ?>">Update</button>
      </div>
      <div class="cell_td cell_td_center" style="width:10%;">
      <button type="button" name="button_delete_task" value="<?php echo($results1->id); ?>">Delete</button>
      </div>
</div>
<?php
}
}
?>
</div>
</div>

{{ Form::close() }}

</div>

  </body>
</html>
@endif