<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;
use DB;

class Tasklogin extends Model
{

function rules($request) {
$validator = Validator::make(

    array(
          'login' => $request->input('login'),
          'password' => $request->input('password'),
    ),

    array(
          'login' => 'regex:/^[\w\d]+$/iu',
          'password' => 'required',
    )

);
return $validator;
}

public function make($request, $method, $query_string)
{
$results=DB::$method($query_string);
return $results;
}

}
