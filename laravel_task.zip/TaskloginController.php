<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Tasklogin;
use Illuminate\Support\Facades\Input;
use Session;

class TaskloginController extends Controller
{

    public function __construct(Tasklogin $tasklogin)
    {
        $this->tasklogin = $tasklogin;
    }

    public function index(Request $request)
    {
        if(Input::get('button_login')) {
           $validator=$this->tasklogin->rules($request);
           if(!$validator->fails()) {
              $method='select';
              $query_string='select `tasks_users`.`id` from `tasks_users` where `tasks_users`.`login`="'.$request->input('login').'" and `tasks_users`.`password`="'.$request->input('password').'"';
              $results=$this->tasklogin->make($request, $method, $query_string);
              if(isset($results[0]->id)) {
                 Session::put('id_user', $results[0]->id);
                 return redirect('/taskcreate');
              }
              else {
                 $message_array['old_login']=$request->input('login');
                 $message_array['error_login']='Mistake in login or password!';
                 return view('tasklogin/tasklogin', ['message_array'=>$message_array]);
              }
           }
           else {
              $message_array['old_login']=$request->input('login');
              $message_array['error_login']='Bad format of login or password!';
              return view('tasklogin/tasklogin', ['message_array'=>$message_array]);
           }
        }
        else {
           return view('tasklogin/tasklogin');
        }

    }
}
