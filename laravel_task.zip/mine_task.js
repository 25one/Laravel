﻿var BaseRecord=(function() {
$(document).ready(function() {
     $("body").on("click", "[name='button_login']", function(){BaseRecord.validate(form_people.login.value, form_people.password.value);});
     $("body").on("keypress", "[name='login']", function(){if(event.which==13) {BaseRecord.validate(form_people.login.value, form_people.password.value);}});
     $("body").on("keypress", "[name='password']", function(){if(event.which==13) {BaseRecord.validate(form_people.login.value, form_people.password.value);}});
     $("body").on("click", "[name='button_add_task']", function(){$(this).attr("type", "submit");});
     $("body").on("click", "[name='button_update_task']", function(){$(this).attr("type", "submit");});
     $("body").on("click", "[name='button_delete_task']", function(){$(this).attr("type", "submit");});
     $("body").on("click", ".button_status_start", function(){BaseRecord.taskstart($(this).attr("name"));});
     $("body").on("click", ".button_status_stop", function(){BaseRecord.taskstop($(this).attr("name"));});
     $("body").on("click", ".button_status_pause", function(){BaseRecord.taskpause($(this).attr("name"));});
});
return {

   var_dump:null,

   validate:function(login, pass) {
      var r=/^[\w\d]+$/i;
      if(!r.test(login) || pass=="") {
         $(".span_error").html("Bad format of login or password!");
      }
      else {
         $(".span_error").html("");
         $("[name='button_login']").attr("type", "submit");
      }
   },

   taskstart:function(id_task) {
      var ajaxSetting={
          method:"post",
          url:"api/taskstart/"+id_task,
          success: function(data) {
             $("[name='"+id_task+"']").css("opacity", "0.5").css("cursor", "pointer");
             $("[name='"+id_task+"'].button_status_start").css("opacity", "1.0");
             $("#id_task"+id_task+".datetime_result").html('');
          },
      };
      $.ajax(ajaxSetting);
   },

   taskstop:function(id_task) {
      var ajaxSetting={
          method:"post",
          url:"api/taskstop/"+id_task,
          success: function(data) {
           var data_json=JSON.parse(data);
           for(var i in data_json) {
            if(i=="error") {
             alert(data_json[i]);
            }
            if(i=="time_result") {
             $("[name='"+id_task+"']").css("opacity", "0.5").css("cursor", "pointer");
             $("[name='"+id_task+"'].button_status_stop").css("opacity", "1.0");
             $("#id_task"+id_task+".datetime_result").html('<span class="span_datatime_result">'+data_json[i]+'</span>');
            }
           }
          },
      };
      $.ajax(ajaxSetting);
   },

   taskpause:function(id_task) {
      var ajaxSetting={
          method:"post",
          url:"api/taskpause/"+id_task,
          success: function(data) {
           var data_json=JSON.parse(data);
           for(var i in data_json) {
            if(i=="error") {
             alert(data_json[i]);
            }
            if(i=="time_result") {
             $("[name='"+id_task+"']").css("opacity", "0.5").css("cursor", "pointer");
             $("[name='"+id_task+"'].button_status_pause").css("opacity", "1.0");
             $("#id_task"+id_task+".datetime_result").html('<span class="span_datatime_result">'+data_json[i]+'</span>');
            }
           }
          },
      };
      $.ajax(ajaxSetting);
   },

};
})();