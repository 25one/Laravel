<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Taskupdate;
use Illuminate\Support\Facades\Input;
use Session;

class TaskupdateController extends Controller
{

    public function __construct(Taskupdate $taskupdate)
    {
        $this->taskupdate = $taskupdate;
    }

    public function index(Request $request)
    {


        if(Input::get('button_update_task')) {
           $method='update';
           $query_string='update `tasks` set `tasks`.`name_task`="'.$request->input('name_task').'", `tasks`.`content_task`="'.$request->input('content_task').'" where `tasks`.`id`='.Session::get('id_task');
           $results=$this->taskupdate->make($request, $method, $query_string);
           return redirect('/taskcreate');
        }
        else {
           $method='select';
           $query_string='select `tasks`.`id_user`, `tasks`.`name_task`, `tasks`.`content_task`, `tasks`.`status`, `tasks`.`datetime_start`, `tasks`.`datetime_end`, `tasks`.`pause_count` from `tasks` where `tasks`.`id`='.Session::get('id_task');
           $results=$this->taskupdate->make($request, $method, $query_string);
           return view('taskupdate/taskupdate', ['results'=>$results]);
        }

    }

}
