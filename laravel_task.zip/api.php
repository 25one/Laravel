<?php

use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Facade;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('select/{id_user}', 'SurpriseController@select');

Route::post('accept', 'SurpriseController@accept');

Route::post('conversion', 'SurpriseController@conversion');

Route::post('unittestone', 'UnittestController@unittestone');

Route::post('taskstart/{id_task}', 'TaskcreateController@taskstart');

Route::post('taskstop/{id_task}', 'TaskcreateController@taskstop');

Route::post('taskpause/{id_task}', 'TaskcreateController@taskpause');

