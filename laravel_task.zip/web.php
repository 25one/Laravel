<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

//Route::get('/todo', function () {
//    return view('todo/todo');
//});

//Route::get('/todo', 'TodoController@index');

//Route::get('/', 'UserController@index');     //...select - owner

Route::get('/', 'HomeController@index');

Route::get('/people', 'PeopleController@index');

Route::get('/formpeople', 'FormpeopleController@index');

Route::get('/casexe', 'CasexeController@index')->name('namecasexe');

Route::post('/casexe', 'CasexeController@index');

Route::get('/surprise', 'SurpriseController@index')->name('namesurprise');

Route::get('/unittest', 'UnittestController@index');

Route::get('/tasklogin', 'TaskloginController@index');

Route::post('/tasklogin', 'TaskloginController@index');

Route::get('/taskcreate', 'TaskcreateController@index');

Route::post('/taskcreate', 'TaskcreateController@index');

Route::get('/taskupdate', 'TaskupdateController@index');

Route::post('/taskupdate', 'TaskupdateController@index');

Auth::routes();

//Route::get('/home', 'HomeController@index');

Route::get('/home', function () {

//return 'function-return-home';
return redirect('/');

});

Route::get('/adduser', 'AdduserController@index');

