<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;
use DB;
use DateTime;

class Taskcreate extends Model
{

public function make($request, $method, $query_string)
{
$results=DB::$method($query_string);
return $results;
}

static function second_into_date($seconds)
{
    $dt = new DateTime('@' . $seconds);
    return array('days'    => $dt->format('z'),
                 'hours'   => $dt->format('G'),
                 'minutes' => $dt->format('i'),
                 'seconds' => $dt->format('s'));
}

}
