<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;
use DB;

class Taskupdate extends Model
{

public function make($request, $method, $query_string)
{
$results=DB::$method($query_string);
return $results;
}

}
